import { NextResponse } from 'next/server';
import { runSelfTest } from '@/lib/beast/selftest';

export const dynamic = 'force-dynamic';
export const maxDuration = 120;

export async function GET() {
  const report = await runSelfTest();
  return NextResponse.json(report, { headers: { 'Cache-Control': 'no-store' } });
}
